function result = reverse_calculate(matA)
    result = sin(log(matA + 2.7)) * log(cos(matA) + 1.7)';
end
